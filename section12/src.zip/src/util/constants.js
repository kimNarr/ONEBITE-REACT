export const emotionList = [
  { emotionId: 1, emotionName: "매우좋음" },
  { emotionId: 2, emotionName: "좋음" },
  { emotionId: 3, emotionName: "보통" },
  { emotionId: 4, emotionName: "나쁨" },
  { emotionId: 5, emotionName: "매우나쁨" },
];
